package com.example.marcel.klientsocketu;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends Activity {

    private Socket socket;
    private PrintWriter out;
    private SocketClient socketClient;
    private Button button;
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        text = (TextView) findViewById(R.id.textView);

    }
    public void main (View v){
        new Thread(new Runnable() {
            @Override
            public void run() {
                connect();
                sendMessage();
            }
        }).start();

    }

    public void main2 (View v){
        new Thread(new Runnable() {
            @Override
            public void run() {
                sendMessage();
            }
        }).start();
    }

    private void connect(){
            if(socket!=null){
                disconnect();
                return;
            }
            String ip = "192.168.0.166";
            int port = 32000;
            try{
                //System.out.println("Connecting to ip 192.168.0.166 on port 32000");
                socket = new Socket (ip, port);
            }catch (Exception e){
                e.printStackTrace();
            }
            socketClient=SocketClient.handle(this,socket);
    }

    public synchronized void disconnect(){
        try{
            socketClient.setDesonnected(true);
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        socket=null;
        out=null;

    }

    public void sendMessage (){
        try{
            if(out==null){
                out = new PrintWriter(new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream())), true);
            }
            out.print("hello\r\n");
            out.flush();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void msgView (String msg){
        text.setText(msg);
    }
}
